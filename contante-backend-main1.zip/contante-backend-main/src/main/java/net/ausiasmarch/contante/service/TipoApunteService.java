// src/main/java/net/ausiasmarch/contante/service/TipoApunteService.java

package net.ausiasmarch.contante.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import net.ausiasmarch.contante.entity.TipoApunteEntity;
import net.ausiasmarch.contante.exception.ResourceNotFoundException;
import net.ausiasmarch.contante.repository.TipoApunteRepository;

@Service
public class TipoApunteService implements TipoApunteServiceInterface {

    @Autowired
    private TipoApunteRepository tipoApunteRepository;

    @Override
    public Page<TipoApunteEntity> getPage(Pageable pageable, Optional<String> filter) {
        if (filter.isPresent()) {
            return tipoApunteRepository
                    .findByDescripcionContainingIgnoreCaseOrComentariosContainingIgnoreCase(filter.get(), filter.get(), pageable);
        } else {
            return tipoApunteRepository.findAll(pageable);
        }
    }
    

    @Override
    public TipoApunteEntity get(Long id) {
        return tipoApunteRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("TipoApunte not found with id " + id));
    }

    @Override
    public TipoApunteEntity create(TipoApunteEntity tipoApunteEntity) {
        return tipoApunteRepository.save(tipoApunteEntity);
    }

    @Override
    public TipoApunteEntity update(TipoApunteEntity tipoApunteEntity) {
        if (!tipoApunteRepository.existsById(tipoApunteEntity.getId())) {
            throw new ResourceNotFoundException("TipoApunte not found with id " + tipoApunteEntity.getId());
        }
        return tipoApunteRepository.save(tipoApunteEntity);
    }

    @Override
    public Long delete(Long id) {
        if (!tipoApunteRepository.existsById(id)) {
            throw new ResourceNotFoundException("TipoApunte not found with id " + id);
        }
        tipoApunteRepository.deleteById(id);
        return id;
    }
}
