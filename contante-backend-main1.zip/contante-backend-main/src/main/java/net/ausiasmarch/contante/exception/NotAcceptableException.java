package net.ausiasmarch.contante.exception;

public class NotAcceptableException extends RuntimeException {
    public NotAcceptableException(String mensaje) {
        super(mensaje);
    }
}
