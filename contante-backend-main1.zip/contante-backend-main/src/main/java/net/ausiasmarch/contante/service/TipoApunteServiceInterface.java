// src/main/java/net/ausiasmarch/contante/service/TipoApunteServiceInterface.java

package net.ausiasmarch.contante.service;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import net.ausiasmarch.contante.entity.TipoApunteEntity;

public interface TipoApunteServiceInterface {
    Page<TipoApunteEntity> getPage(Pageable pageable, Optional<String> filter);
    TipoApunteEntity get(Long id);
    TipoApunteEntity create(TipoApunteEntity tipoApunteEntity);
    TipoApunteEntity update(TipoApunteEntity tipoApunteEntity);
    Long delete(Long id);
}
