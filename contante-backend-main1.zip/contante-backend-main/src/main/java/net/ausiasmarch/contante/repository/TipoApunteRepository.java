// src/main/java/net/ausiasmarch/contante/repository/TipoApunteRepository.java

package net.ausiasmarch.contante.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import net.ausiasmarch.contante.entity.TipoApunteEntity;

@Repository
public interface TipoApunteRepository extends JpaRepository<TipoApunteEntity, Long> {

    // Custom method to search by descripcion or comentarios with a LIKE query
    Page<TipoApunteEntity> findByDescripcionContainingIgnoreCaseOrComentariosContainingIgnoreCase(
            String descripcion, String comentarios, Pageable pageable);

    
}

