package net.ausiasmarch.dado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DadoApplicationTests {

	@Test
	void contextLoads() {
	}

}
